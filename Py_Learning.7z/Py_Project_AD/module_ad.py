
def ad_detection():
    print("I am in detection module")
