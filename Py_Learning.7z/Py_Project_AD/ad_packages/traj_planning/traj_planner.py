
def find_traj_fnc():
    print("In traj planning file")