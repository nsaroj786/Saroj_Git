
def perception_pkg_fnc():
    print ("In python package- perception")