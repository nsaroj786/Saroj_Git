#!usr/bin/python
print ("### Modules in Python ###") # folder=package , file = module

import modules_in_python     #way to import file/module from same file
import module_shopping.shopping_cart

print (modules_in_python)
print(modules_in_python.multiply(10,2))
print(modules_in_python.divide(10,2))

#print(module_shopping.shopping_cart.sopping_cart_fun())


